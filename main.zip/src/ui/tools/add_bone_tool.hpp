#pragma once

#include "tool.hpp"

namespace ui {

    namespace canvas {
        class manager;
    }

    namespace tool {
        class add_bone : public base {
        private:
            QPointF origin_;
            QGraphicsLineItem* rubber_band_;
            mdl::project* model_;

            void init_rubber_band(canvas::scene& c);

        public:
            add_bone();
            void init(canvas::manager& canvases, mdl::project& model) override;
            void mousePressEvent(canvas::scene& c, QGraphicsSceneMouseEvent* event) override;
            void mouseMoveEvent(canvas::scene& c, QGraphicsSceneMouseEvent* event) override;
            void mouseReleaseEvent(canvas::scene& c, QGraphicsSceneMouseEvent* event) override;
        };
    }
}